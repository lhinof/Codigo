package HerenciaPersona;

import hola.Docente;
import hola.Estudiante;

public class main {

	public static void main(String[] args) {
		Persona a=new Persona("juan",18,"varon");
		//a.mostrar();
		System.out.println("---------------");
		Docente d1=new Docente("Pedro",30,"varon","informatica","M056");
		Docente d2=new Docente("Ana",25,"mujer","informatica","M056");
		Docente d3=new Docente("Pedro",40,"varon","medico","M056");
		Docente d4=new Docente("Juan",27,"varon","medico","M056");
		Docente d5=new Docente("Mauricio",33,"varon","Informatica","M056");
		
		
		Docente vd[]=new Docente[5];
		vd[0]=d1;
		vd[1]=d2;
		vd[2]=d3;
		vd[3]=d4;
		vd[4]=d5;
		
		/*
		for(int i=0;i<vd.length;i++) {
			if(vd[i].getProfesion().equals("informatica")) {
				vd[i].mostrar();
			}
		}
		*/
		Estudiante e1=new Estudiante("A",18,"mujer","2024-1234",85);
		Estudiante e2=new Estudiante("B",18,"mujer","2024-1234",10);
		Estudiante e3=new Estudiante("C",18,"mujer","2024-1234",100);
		Estudiante e4=new Estudiante("D",18,"mujer","2024-1234",70);
		
		Estudiante ve[]=new Estudiante[4];
		
		ve[0]=e1;
		ve[1]=e2;
		ve[2]=e3;
		ve[3]=e4;
		
		/*int may=0;
		String nom="";
		for(int j=0;j<ve.length;j++) {
			if(ve[j].getNotaFinal()>=may) {
				may=ve[j].getNotaFinal();
				nom=ve[j].getNombre();
			}
			
		}
		System.out.println("Mejor nota:"+may+", Estudiante:"+nom);
		*/
		
		Persona vp[]=new Persona[3];
		
		vp[0]=d1;
		vp[1]=e1;
		vp[2]=a;
		
		for(int k=0;k<vp.length;k++) {
			vp[k].mostrar();
		}
		
		
		
		
	}

}
