package HerenciaPersona;
import java.util.Scanner;
public class Estudiante extends Persona{
		protected String matricula;
		protected int notaFinal;
		public Estudiante()
		{
			super();
			matricula="";
			notaFinal=0;
		}
		public Estudiante(String n, int e, String g, String m, int nf) {
			super(n,e,g);
			this.matricula=m;
			this.notaFinal=nf;
		}
		public void leer() {
			Scanner sc=new Scanner(System.in);
			super.leer();
			System.out.println("Ingresa la matricula: ");
			this.matricula= sc.next();
			System.out.println("Ingresa la nota final: ");
			this.notaFinal= sc.nextInt();
			sc.close();
		}
		public void mostrar() {
			super.mostrar();
			System.out.println("-----DATOS ESTUDIANTE------");
			System.out.println("La matricula es: "+matricula+", la nota FINAL es: "+notaFinal);
		}
		public String getMatricula() {
			return matricula;
		}
		public void setMatricula(String matricula) {
			this.matricula = matricula;
		}
		public int getNotaFinal() {
			return notaFinal;
		}
		public void setNotaFinal(int notaFinal) {
			this.notaFinal = notaFinal;
		}
		
}

