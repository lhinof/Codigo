package HerenciaPersona;
import java.util.Scanner;
public class Docente extends Persona{
	protected String profesion;
	protected String item;
	//Atributos con herencia
	public Docente() {
		super();
		//o podemos usar estos 
		//super.nombre="";
		item="";
		profesion="";
	}
	public Docente(String n, int e, String g, String p, String i) {
		super(n,e,g);
		this.item=i;
		this.profesion=p;
		
	}
	public void leer()
	{
		Scanner sc=new Scanner(System.in);
		super.leer();
		System.out.println("Ingresa la profesion: ");
		this.profesion= sc.next();
		System.out.println("Ingresa el item: ");
		this.item= sc.next();
		sc.close();
	}
	public void mostrar() {
		super.mostrar();
		System.out.println("-----------DATOS DEL DOCENTE------");
		System.out.println("La profesion: "+profesion+", el item "+item);
	}
	public String getProfesion() {
		return profesion;
	}
	public void setProfesion(String profesion) {
		this.profesion = profesion;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public void mostrarCarrera() {
		char z=this.item.charAt(0);
		switch(z) {
		case'I':System.out.println("Informatica");break;
		case'E':System.out.println("Estadistica");break;
		case'M':System.out.println("Medicina");break;
		case'B':System.out.println("Biologia");break;
		default:System.out.println("Codigo inexistente");
		}
	}
}
