package HerenciaPersona;
import java.util.Scanner;
//CLASE PERSONA
public class Persona {
	protected String nombre;
	protected int edad;
	protected String genero;
//CLASE PERSONA ATRIBUTOS	
public Persona(){
	this.nombre="";
	this.edad=0;
	this.genero="";
}
//CLASE METODOS GENERALES
public Persona(String n, int e ,String g){
	this.nombre=n;
	this.edad=e;
	this.genero=g;
}
public void leer() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Ingrese el nombre de la persona: ");
	this.nombre=sc.next();
	System.out.println("Ingrese la edad de la persona: ");
	this.edad=sc.nextInt();
	System.out.println("Ingrese el genero de la persona: ");
	this.genero=sc.next();
	sc.close();
}
public void mostrar() {
	System.out.println("-------------DATOS DE PERSONA-----------------");
	System.out.println("el nombre es "+nombre+", la edad es "+edad+ ", el genero es "+genero);	
}
//GETTERS Y SETTERS
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public int getEdad() {
	return edad;
}
public void setEdad(int edad) {
	this.edad = edad;
}
public String getGenero() {
	return genero;
}
public void setGenero(String genero) {
	this.genero = genero;
}
//FIN
}